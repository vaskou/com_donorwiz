<?php

defined('_JEXEC') or die;

?>

<?php echo JLayoutHelper::render( 'dashboard.user', array ( ) , JPATH_ROOT .'/components/com_donorwiz/layouts' , null ); ?>

